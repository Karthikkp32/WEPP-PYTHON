from django.contrib import admin
from .models import Trainer, TrainingProgram

admin.site.register(Trainer)
admin.site.register(TrainingProgram)
