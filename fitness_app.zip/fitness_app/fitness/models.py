# fitness/models.py
from django.db import models
from django.contrib.auth.models import User
import qrcode
from io import BytesIO
from django.core.files.base import ContentFile
from PIL import Image

class Trainer(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class TrainingProgram(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    trainer = models.ForeignKey(Trainer, on_delete=models.CASCADE)
    training_type = models.CharField(max_length=50)
    duration_months = models.IntegerField()
    cost_per_month = models.FloatField()
    access_id = models.CharField(max_length=50, unique=True, null=True)
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True)

    def total_cost(self):
        return self.duration_months * self.cost_per_month

    def generate_qr_code(self):
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr_data = f"Member: {self.user.username}\nTrainer: {self.trainer.name}\nProgram: {self.training_type}\nAccess ID: {self.access_id}"
        qr.add_data(qr_data)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        filename = f'qr_{self.access_id}.png'
        self.qr_code.save(filename, ContentFile(buffer.getvalue()), save=False)

class Feedback(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name}'s feedback on {self.created_at.strftime('%Y-%m-%d')}"
