from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from .models import Trainer, TrainingProgram, Feedback
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
import uuid

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('training_form')
        else:
            messages.error(request, "Please enter a correct username and password. Note that both fields may be case-sensitive.")
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

@login_required
def training_form(request):
    trainers = Trainer.objects.all()
    if request.method == 'POST':
        training_type = request.POST['training_type']
        trainer_id = request.POST['trainer']
        duration = int(request.POST['duration'])

        trainer = Trainer.objects.get(id=trainer_id)
        # Set predefined cost based on training type
        if training_type == 'Cardio':
            cost_per_month = 1500.0
        elif training_type == 'Strength':
            cost_per_month = 2000.0
        else:  # Yoga
            cost_per_month = 1800.0

        # Generate unique access ID
        access_id = str(uuid.uuid4())[:8].upper()
        
        program = TrainingProgram.objects.create(
            user=request.user,
            training_type=training_type,
            trainer=trainer,
            duration_months=duration,
            cost_per_month=cost_per_month,
            access_id=access_id
        )
        
        # Generate QR code
        program.generate_qr_code()
        program.save()

        return render(request, 'training_form.html', {
            'trainers': trainers,
            'success': True,
            'total_cost': program.total_cost()
        })

    return render(request, 'training_form.html', {'trainers': trainers})

def logout_view(request):
    logout(request)
    return redirect('login')

def submit_feedback(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        
        try:
            # Save feedback to database
            feedback = Feedback.objects.create(
                name=name,
                email=email,
                message=message
            )
            
            # Send email notification
            send_mail(
                'New Fitness App Feedback',
                f'Name: {name}\nEmail: {email}\nFeedback: {message}',
                settings.DEFAULT_FROM_EMAIL,
                ['varunjagadeesh24@gmail.com'],
                fail_silently=True,
            )
            
            messages.success(request, 'Thank you for your feedback! We will get back to you soon.')
        except Exception as e:
            # Log the error (in production, use proper logging)
            print(f'Error sending feedback email: {str(e)}')
            messages.success(request, 'Thank you for your feedback! We have received your message.')
        
        return redirect('feedback')
    
    return render(request, 'feedback.html')
